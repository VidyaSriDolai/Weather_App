$(document).ready(function () {
  $('#searchBtn').click(function () {
    const cityInput = $('#cityInput').val().trim().toLowerCase();

    if (cityInput === '') {
      $('#weatherResult').html('<p class="text-warning">Please enter a city name.</p>');
      return;
    }

    const finalCity = cityInput.includes(',') ? cityInput : `${cityInput},in`;
    const apiKey = '89482425983d9e17b5c2e7f1ef68a70b'; // ✅ Your API key here
    const url = `https://api.openweathermap.org/data/2.5/weather?q=${finalCity}&appid=${apiKey}&units=metric`;

    $('#loader').show();
    $('#weatherResult').empty();

    $.get(url)
      .done(function (data) {
        const iconCode = data.weather[0].icon;
        const iconUrl = `https://openweathermap.org/img/wn/${iconCode}@2x.png`;

        const weatherHtml = `
          <div class="card bg-secondary text-white">
            <div class="card-body">
              <h4 class="card-title">${data.name}, ${data.sys.country}</h4>
              <img src="${iconUrl}" alt="Weather icon" class="weather-icon"/>
              <p><strong>Temperature:</strong> ${data.main.temp} °C</p>
              <p><strong>Humidity:</strong> ${data.main.humidity}%</p>
              <p><strong>Wind Speed:</strong> ${data.wind.speed} m/s</p>
              <p><strong>Condition:</strong> ${data.weather[0].description}</p>
            </div>
          </div>
        `;
        $('#weatherResult').html(weatherHtml);
        addToHistory(data.name + ', ' + data.sys.country);
      })
      .fail(function (xhr) {
        let message = "City not found!";
        if (xhr.responseJSON && xhr.responseJSON.message) {
          message = xhr.responseJSON.message;
        }
        $('#weatherResult').html(`<p class="text-danger">${message}</p>`);
      })
      .always(function () {
        $('#loader').hide();
      });
  });

  function addToHistory(city) {
    if ($(`#historyList li:contains("${city}")`).length === 0) {
      const li = `<li class="list-group-item bg-dark text-white">${city}</li>`;
      $('#historyList').prepend(li);
    }
  }
});